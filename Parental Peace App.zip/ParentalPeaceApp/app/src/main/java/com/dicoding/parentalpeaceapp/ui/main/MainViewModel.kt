package com.dicoding.parentalpeaceapp.ui.main

import androidx.lifecycle.ViewModel
import com.dicoding.parentalpeaceapp.data.Repository
import java.io.File

class MainViewModel(private val repository: Repository) : ViewModel() {
    fun uploadAudio(file: File) = repository.uploadAudio(file)
}