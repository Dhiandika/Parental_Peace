package com.dicoding.parentalpeaceapp.ui.signup

import androidx.lifecycle.ViewModel
import com.dicoding.parentalpeaceapp.data.Repository

class SignUpViewModel(private val repository: Repository) : ViewModel() {

    suspend fun register(name: String, email: String, phone: String, password: String) = repository.
    register(name, email, phone, password)
}