package com.dicoding.parentalpeaceapp.data

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.liveData
import com.dicoding.parentalpeaceapp.data.database.ParentalPeaceDatabase
import com.dicoding.parentalpeaceapp.response.ArticleResponse
import com.dicoding.parentalpeaceapp.response.DataItem
import com.dicoding.parentalpeaceapp.response.RecordUploadResponse
import com.dicoding.parentalpeaceapp.response.SignInResponse
import com.dicoding.parentalpeaceapp.result.Result
import com.dicoding.parentalpeaceapp.retrofit.ApiService
import com.google.gson.Gson
import kotlinx.coroutines.flow.Flow
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import retrofit2.Callback
import retrofit2.Call
import retrofit2.HttpException
import retrofit2.Response
import java.io.File

class Repository(
    private val database: ParentalPeaceDatabase,
    private val userPreference: UserPreference,
    private val apiService: ApiService) {

    private val _signin = MutableLiveData<SignInResponse>()
    var signin: MutableLiveData<SignInResponse> = _signin

    private var _listArticle = MutableLiveData<List<DataItem>?>()
    var listArticle: MutableLiveData<List<DataItem>?> = _listArticle

    private val _isLoading = MutableLiveData<Boolean>()

    suspend fun register(name: String, email: String, phone: String, password: String) = apiService.
    register(name, email, phone, password)


    fun signIn(email: String, password: String) {
        _isLoading.value = true
        val client = apiService.login(email, password)
        client.enqueue(object : Callback<SignInResponse> {
            override fun onResponse(
                call: Call<SignInResponse>,
                response: Response<SignInResponse>
            ) {
                if (response.isSuccessful) {
                    _isLoading.value = false
                    _signin.value = response.body()
                }
            }

            override fun onFailure(call: Call<SignInResponse>, t: Throwable) {
                Log.e("Repository", "error: ${t.message}")
            }
        })
    }

    fun uploadAudio(audioFile: File)  = liveData {
        emit(Result.Loading)
        val requestAudioFile = audioFile.asRequestBody("audio/mav".toMediaTypeOrNull())
        val multipartBody = MultipartBody.Part.createFormData(
            "audio",
            audioFile.name,
            requestAudioFile
        )
        try {
            val successResponse = apiService.uploadAudio(multipartBody)
            emit(Result.Success(successResponse))
        } catch (e: HttpException) {
            val errorBody = e.response()?.errorBody()?.string()
            val errorResponse = Gson().fromJson(errorBody, RecordUploadResponse::class.java)
            emit(Result.Error(errorResponse.status))
        }
    }

    fun listArticle() {
        val client = apiService.getArticle()
        client.enqueue(object : Callback<ArticleResponse> {
            override fun onResponse(
                call: Call<ArticleResponse>,
                response: Response<ArticleResponse>
            ) {
                if (response.isSuccessful) {
                    _listArticle.value = response.body()?.data
                }
            }

            override fun onFailure(call: Call<ArticleResponse>, t: Throwable) {
                Log.e("Repository", "error: ${t.message}")
            }
        })
    }

    suspend fun saveSession(user: UserModel) {
        userPreference.saveSession(user)
    }

    fun getSession(): Flow<UserModel> {
        return userPreference.getSession()
    }

    suspend fun logout() {
        userPreference.logout()
    }

    companion object {
        @Volatile
        private var instance: Repository? = null

        fun getInstance(
            database: ParentalPeaceDatabase,
            userPreference: UserPreference,
            apiService: ApiService
        ): Repository =
            instance ?: synchronized(this) {
                instance ?: Repository(database, userPreference, apiService)
            }.also { instance = it }

        fun clearInstance() {
            instance = null
        }
    }
}