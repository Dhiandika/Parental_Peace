package com.dicoding.parentalpeaceapp.ui.signin

import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.viewModels
import androidx.lifecycle.lifecycleScope
import com.dicoding.parentalpeaceapp.R
import com.dicoding.parentalpeaceapp.data.UserModel
import com.dicoding.parentalpeaceapp.databinding.ActivitySignInBinding
import com.dicoding.parentalpeaceapp.response.SignInResponse
import com.dicoding.parentalpeaceapp.ui.main.MainActivity
import com.dicoding.parentalpeaceapp.ui.ViewModelFactory
import com.dicoding.parentalpeaceapp.ui.signup.SignUpActivity
import com.google.gson.Gson
import kotlinx.coroutines.launch
import retrofit2.HttpException

class SignInActivity : AppCompatActivity() {

    private val viewModel by viewModels<SignInViewModel> {
        ViewModelFactory.getInstance(this)
    }

    private lateinit var binding: ActivitySignInBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        binding = ActivitySignInBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        showLoading(false)

        setupView()
        setupAction()

        binding.tvSignupClick.setOnClickListener {
            val intent = Intent(this, SignUpActivity::class.java)
            startActivity(intent)
        }
    }

    private fun setupView() {
        @Suppress("DEPRECATION")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.hide(WindowInsets.Type.statusBars())
        } else {
            window.setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
            )
        }
        supportActionBar?.hide()
    }

    private fun setupAction() {
        binding.btnSignin.setOnClickListener {
            val email = binding.etEmailLogin.text.toString()
            val password = binding.etPassword.text.toString()

            if (email.isEmpty() || password.isEmpty()) {
                showToast(getString(R.string.null_email))
                return@setOnClickListener
            }

            showLoading(true) // Tampilkan loading bar saat proses login dimulai

            try {
                viewModel.signIn(email, password)
                viewModel.signin.observe(this) {
                    Log.e("Login", "it: $it")
                    showLoading(false) // Sembunyikan loading bar saat login berhasil
                    showToast(getString(R.string.signin_success))
                    saveUser(
                        UserModel(
                            it.loginResult.token,
                            it.loginResult.name,
                            it.loginResult.userId,
                            true
                        )
                    )
                }
            } catch (e: HttpException) {
                showLoading(false) // Sembunyikan loading bar saat login gagal
                val errorBody = e.response()?.errorBody()?.string()
                val errorResponse = Gson().fromJson(errorBody, SignInResponse::class.java)
                showToast(errorResponse.message)
            }
        }
    }


    private fun saveUser(session: UserModel) {
        lifecycleScope.launch {
            viewModel.saveSession(session)
            val intent = Intent(this@SignInActivity, MainActivity::class.java)
            intent.putExtra("SHOW_FRAGMENT", "HOME_FRAGMENT") // Informasi tambahan
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
            ViewModelFactory.clearInstance()
            startActivity(intent)
        }
    }

    private fun showToast(message: String?) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun showLoading(isLoading: Boolean) {
        binding.btnSignin.isEnabled = !isLoading
        binding.tvSignupClick.isEnabled = !isLoading
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }
    
}