package com.dicoding.parentalpeaceapp.ui.signin

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dicoding.parentalpeaceapp.data.Repository
import com.dicoding.parentalpeaceapp.data.UserModel
import com.dicoding.parentalpeaceapp.response.SignInResponse
import kotlinx.coroutines.launch

class SignInViewModel(private val repository: Repository) : ViewModel()  {

    var signin : MutableLiveData<SignInResponse> = repository.signin

    fun signIn(email: String, password: String) = repository.signIn(email, password)

    fun saveSession(user: UserModel) {
        viewModelScope.launch {
            repository.saveSession(user)
        }
    }
}