package com.dicoding.parentalpeaceapp.ui.signup

import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.lifecycleScope
import com.dicoding.parentalpeaceapp.R
import com.dicoding.parentalpeaceapp.databinding.ActivitySignUpBinding
import com.dicoding.parentalpeaceapp.response.SignUpResponse
import com.dicoding.parentalpeaceapp.ui.signin.SignInActivity
import com.dicoding.parentalpeaceapp.ui.ViewModelFactory
import com.google.gson.Gson
import kotlinx.coroutines.launch
import retrofit2.HttpException

class SignUpActivity : AppCompatActivity() {

    private val viewModel by viewModels<SignUpViewModel> {
        ViewModelFactory.getInstance(this)
    }

    private lateinit var binding: ActivitySignUpBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        binding = ActivitySignUpBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        showLoading(false)

        setupView()
        setupAction()

        binding.tvSigninClick.setOnClickListener {
            val intent = Intent(this, SignInActivity::class.java)
            startActivity(intent)
        }

        binding.backButton1.setOnClickListener {
            finish()
        }
    }

    private fun setupView() {
        @Suppress("DEPRECATION")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.hide(WindowInsets.Type.statusBars())
        } else {
            window.setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
            )
        }
        supportActionBar?.hide()
    }

    private fun setupAction() {
        binding.btnCrtAccount.setOnClickListener {
            showLoading(true)
            val name = binding.etName.text.toString()
            val email = binding.etEmail.text.toString()
            val phone = binding.etNumber.text.toString()
            val password = binding.etPassword.text.toString()

            when {
                name.isEmpty() -> {
                    showLoading(false)
                    binding.etName.error = getString(R.string.null_name)
                }
                email.isEmpty() -> {
                    showLoading(false)
                    binding.etEmail.error = getString(R.string.null_email)
                }
                password.isEmpty() -> {
                    showLoading(false)
                    binding.etPassword.error = getString(R.string.null_password)
                }
                else -> {
                    showLoading(true)
                    lifecycleScope.launch {
                        try {
                            val response = viewModel.register(name, email, phone, password)
                            showLoading(false)
                            showToast(response.message)
                            AlertDialog.Builder(this@SignUpActivity).apply {
                                setTitle("Nice!")
                                setMessage(getString(R.string.regis_succses))
                                setPositiveButton(getString(R.string.next)) { _, _ ->
                                    val intent = Intent(context, SignInActivity::class.java)
                                    intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
                                    startActivity(intent)
                                    finish()
                                }
                                create()
                                show()
                            }
                        } catch (e: HttpException) {
                            showLoading(false)
                            val errorBody = e.response()?.errorBody()?.string()
                            val errorResponse = Gson().fromJson(errorBody, SignUpResponse::class.java)
                            showToast(errorResponse.message)
                        }
                    }
                }
            }
        }
    }

    private fun showLoading(isLoading: Boolean) {
        binding.btnCrtAccount.isEnabled = !isLoading
        binding.tvSigninClick.isEnabled = !isLoading
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}